package com.just.six.user.cmn;

public class DTO {

}
