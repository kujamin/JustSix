package com.just.six.user.dao;

import com.just.six.user.cmn.WorkDiv;
import com.just.six.user.domain.UserVO;

public interface UserDao extends WorkDiv<UserVO>{

}
