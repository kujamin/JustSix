package com.just.six.music.dao;

import com.just.six.user.cmn.WorkDiv;
import com.just.six.user.domain.MusicVO;

public interface MusicDao extends WorkDiv<MusicVO>{

}
